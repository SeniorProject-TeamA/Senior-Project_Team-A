<?php
require_once("user.class.php");
require_once("memo.class.php");
require_once("dba.class.php");
require_once("work-order.class.php");
require_once("cust.class.php");


use WSC\Framework\Agents\User;
use WSC\Framework\Agents\Memo;
use WSC\Framework\Adapters\DBA;
use WSC\Framework\Agents\workOrder;
use WSC\Framework\Agents\customer;

// -----------------------------------------------------

$db = new DBA();
$sql = "SELECT EmployeeID,FirstName, LastName FROM employee ";
$result = $db->query($sql);

/*foreach ($result as $key => $value) {
    echo 'Key: ' . $key . '<br>';
    foreach ($value as $v) {
        echo '  Value: ' . $v . '<br>';
    }
}*/

foreach ($result as $key => $value) {
    echo 'Key: ' . $key . '<br>';
    var_dump($value);
}

/*if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Name</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["EmployeeID"]."</td><td>".$row["FirstName"]." ".$row["LastName"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}*/


//var_dump($db);

/*$tbl_arr = array(
    "hire_date" => "",
    "first_name" => "",
    "last_name" => "",
    "street" => "",
    "city" => "",
    "state" => "",
    "zip" => "",
    "phone_home" => "",
    "phone_cell" => ""
);

$tbl_data = array(
    "emp_id"     => "012345",
    "hire_date"  => "03/15/20",
    "first_name" => "James",
    "last_name"  => "Coltman",
    "street"     => "123 Street Name",
    "city"       => "Big City",
    "state"      => "IL",
    "zip"        => "12345",
    "phone_home" => "(555)123-4567",
    "phone_cell" => "(545)123-4567"
);

$tbl_req = array(
    "emp_id",
    "hire_date",
    "first_name",
    "last_name",
    "street",
    "city",
    "state",
    "zip",
    "phone_home",
    "phone_cell"
);

$rows = $db->insert("employee", $tbl_data, $tbl_req); */

/*$message = new Memo("An order is ready for review", "Jim Johnson, Operations Manager", "001234");

echo $message -> constructMemo();*/

/*$servername = "127.0.0.1";
$username = "James";
$password = "Coltman";
$dbname = "williams";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT EmployeeID,FirstName, LastName FROM employee ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Name</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["EmployeeID"]."</td><td>".$row["FirstName"]." ".$row["LastName"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
*/

?>