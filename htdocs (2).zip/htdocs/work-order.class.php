<?php

/**
* This class is will handle all work order processes
*
* @package      workOrders
* @category     Agent
* @author       James R. Coltman <iamthecoltman@gmail.com>
*/

namespace WSC\Framework\Agents;

use WSC\Framework\Agents\workOrder;

class workOrder {

    private $empID;
    private $jobType;
    private $mediaType;
    private $content;


    public function __construct($empID, $custType, $jobType, $mediaType, $content) {

    }

    private function set_work_order($empID, $custType, $jobType, $mediaType, $content) {
        protected $customer;      # Object: customer
        protected $typestring = "";

       /* if ($custType == "new"){
            //NewCustomer
        }
        else if($custType == "existing"){
            //ExistingCustomer
        }
        else {
            // Error
        }*/

        switch ($custType) {
            case 'existing':
                # code...
                break;
            case 'new':
                #code...
                break;
            default:
                # code...
                break;
        }

    }


}
?>