<?php




/*Class DB {
    protected $db;
    protected $db2;

    public function __construct() {
        echo "Class: (" . __CLASS__ . ") Instantiated!" . PHP_EOL;

        $this->db = array(
            "James"  => "Coltman01",
            "Justin" => "Byrne03",
            "Joe"    => "Gibson99",
            "John"   => "Boley20",
            "Jim"    => "Robbins45"
        );
        $this->db2 = array(
            "James"  => "SalesPerson",
            "Justin" => "Operations Manger",
            "Joe"    => "Printer/Engraver Specialist",
            "John"   => "Stock Room",
            "Jim"    => "Customer"
        );
    }

    public function getPass($user) {
        $result;

        foreach ($this->db as $key => $value) {
            if ($key == $user) {
                $result = $value;
            }
        }

        return $result;

    }

        public function getJobTitle($user) {
        $result;

        foreach ($this->db2 as $key => $value) {
            if ($key == $user) {
                $result = $value;
            }
        }

        return $result;

    }
}*/


?>