<?php
/**
* This class sends and recieves memos
*
* @package      Memo
* @category     Agent
* @author       James R. Coltman <iamthecoltman@gmail.com>
*/

namespace WSC\Framework\Agents;

use WSC\Framework\Agents\Memo;
/**
 * [description]
 *
 * [Detailed Description]
 */
Class Memo {
    private $message;
    private $target;
    private $orderId;


/**
 * [description]
 *
 * [Detailed Description]
 */
        public function __construct($message,$target,$orderId)
    {
        echo "Class: (" . __CLASS__ . ") Instantiated!" . PHP_EOL;

        $this->setMessage($message);

        $this->setTarget($target);

        $this->setOrderId($orderId);

        $this->constructMemo($message, $target, $orderId);

    }
    /**
     * [setMessage description]
     * @param [type] $message [description]
     */
        private function setMessage($message)
    {
        $this->message = $message;
    }
/**
 * [setTarget description]
 * @param [type] $target [description]
 */
        private function setTarget($target)
    {
        $this->target = $target;
    }
/**
 * [setOrderID description]
 * @param [type] $orderId [description]
 */
        private function setOrderID($orderId)
    {
        $this->orderId = $orderId;
    }
/**
 * [getMessage description]
 * @return [type] [description]
 */
        public function getMessage()
    {
        return $this->$message;
    }
/**
 * [getTarget description]
 * @return [type] [description]
 */
        public function getTarget()
    {
        return $this->$target;
    }
/**
 * [getOrderID description]
 * @return [type] [description]
 */
        public function getOrderID()
    {
        return $this->$orderId;
    }
/**
 * [constructMemo description]
 * @return [type] [description]
 */
        public function constructMemo()
    {

        $result;

        $result = '<br>'."Attn ".$this->target.": Ref Order ".$this->orderId.'<br>'.$this->message;

        return $result;
/**
 *
 */
    }
        Public function sendMemo()
    {
        return;
    }



}
?>