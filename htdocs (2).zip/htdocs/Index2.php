<?php

class person{

    public $eyes = "green";
    public $hair = "brown";
    public $height = 5.9;

    public function move($steps){
        $convert_amount=0.000762;
        $result=$steps*$convert_amount;

        return $result;

    }

    public function speak($message){

        return'person says: '. $message;

    }

    public function sleep($time){


    }



}
$person=new person;

$person->eyes="blue";
echo $person->eyes;




?>