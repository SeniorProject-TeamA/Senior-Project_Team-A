<?php

/**
* This class will handle customers
*
* @package      customer
* @category     Agent
* @author       James R. Coltman <iamthecoltman@gmail.com>
*/

namespace WSC\Framework\Agents;

use WSC\Framework\Agents\customer;

    private $firstName;
    private $lastName;
    private $address;
    private $phone;
    private $email;

    public function __construct($firstName, $lastName, $address, $phone, $email) {

    }

     private function set_customer($firstName, $lastName, $address, $phone, $email) {
        $result;
do {
            if (!$isset($firstName)) {
                $result = "First name is not set";
            }

            if (!$isset($lastName)) {
                $result = "Last name is not set";
            }

            if (!$isset($address)) {
                $result = "No address is not set";
            }

            if (!$isset($phone)) {
                $result = "Phone number is not set";
            }
            else $result=

        } while(0);

    $stmt = "INSERT INTO customer (FirstName, LastName, Address, City, PostalCode, Country)";

    }

    private function get_customer(){

    }


?>